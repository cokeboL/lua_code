local test = require("./MapInfo")

local function print_table(tab)
	for k, v in pairs(tab) do
		if type(v) == 'table' then
			print_table(v)
		else
			print(k, v)
		end
	end
end

print_table(test)