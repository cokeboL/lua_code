local json = require("json")
local mp = require("MessagePack")
local LuaProto = require("LuaProto")
LuaProto.load("MsgConfig", "MsgConfig2")
local newMsg = LuaProto.newMsg
local getMsg = newMsg--LuaProto.getMsg
local getMsgN = LuaProto.getMsgN
local encode = LuaProto.encode
local decode = LuaProto.decode
local jencode = json.encode
local jdecode = json.decode
local mpack = mp.pack
local munpack = mp.unpack




local function getFriend()
	return
	{
		name = "name",
		coin = 120,
		health = "ok",
	}
end
local function getJsMpMsg()
	local tab =
	{
		id = "xxxx2",
		idx = 1004,
		friends = {}
	}
	tab.friend = getFriend()
	tab.friends[1] = getFriend()
	tab.friends[2] = getFriend() 
	
	return tab
end

local start
local loop = 1000000
print(string.format("*************** test 1, loop: %d ***************", loop))

start = os.time()
---[[
local msg = newMsg("MSG_PLAYER2")
msg.friend = newMsg("MSG_FRIEND2")
msg.friends[1] = newMsg("MSG_FRIEND2")
msg.friends[2] = newMsg("MSG_FRIEND2")
--]]
--local msg = getJsMpMsg()
for i=1, loop do
	local str = encode(msg)
	local player = decode(str)
end
---[[
local lmsg = newMsg("MSG_PLAYER2")
lmsg.friend = newMsg("MSG_FRIEND2")
lmsg.friends[1] = newMsg("MSG_FRIEND2")
lmsg.friends[2] = newMsg("MSG_FRIEND2")
--]]
--local lmsg = getJsMpMsg()
local str = encode(lmsg)
lmsg = decode(str)

print("len lp: ", string.len(str))
print("use lp: ", os.time()-start)


start = os.time()
local msg = getJsMpMsg()
for i=1, 1 do
	local str = jencode(msg)
	--print("len json: ", string.len(str))
	local player = jdecode(str)
end
local jmsg = getJsMpMsg()
local str = jencode(jmsg)
print("len json: ", string.len(str))
print("use json: ", os.time()-start)


start = os.time()
local msg = getJsMpMsg()
for i=1, loop do
	local str = mpack(msg)
	--print("len mp: ", string.len(str))
	local player = munpack(str)
end
local mmsg = getJsMpMsg()
local str = mpack(mmsg)
print("len mp: ", string.len(str))
print("use mp: ", os.time()-start)
print("-------------- msg:")
LuaProto.dump(lmsg)

local loop = 5000000
print(string.format("*************** test , loop: %d ***************", loop))

start = os.time()
local msg = newMsg("MSG_FRIEND2")
for i=1, loop do
	local str = encode(msg)
	local player = decode(str)
end
local lmsg = newMsg("MSG_FRIEND2")
local str = encode(lmsg)
lmsg = decode(str)
print("len lp: ", string.len(str))
print("use lp: ", os.time()-start)


start = os.time()
local msg = getFriend()
for i=1, 1 do
	local str = jencode(msg)
	--print("len json: ", string.len(str))
	local player = jdecode(str)
end
local jmsg = getFriend()
local str = jencode(jmsg)
print("len json: ", string.len(str))
print("use json: ", os.time()-start)


start = os.time()
local msg = getFriend()
for i=1, loop do
	local str = mpack(msg)
	--print("len mp: ", string.len(str))
	local player = munpack(str)
end
local mmsg = getFriend()
local str = mpack(mmsg)
print("len mp: ", string.len(str))
print("use mp: ", os.time()-start)

print("-------------- msg:")
LuaProto.dump(lmsg)
print(string.format("*************** test over ***************"))