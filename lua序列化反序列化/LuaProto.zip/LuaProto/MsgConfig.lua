local T_NUMBER = 1
local T_STRING = 2
local T_TABLE  = 3
local T_ARRAY  = 4

local MESSAGES
MESSAGES =
{
	MSG_FRIEND =
	{
		{T_STRING, "name", "name"},
		{T_NUMBER, "coin", 120},
		{T_STRING, "health", "ok"},
		--[[
		create = function()
			return
			{
				name = "name",
				coin = 120,
				health = "ok",
			}
		end
		--]]
	},

	MSG_PLAYER =
	{
		{T_STRING, "id", "xxxxx2"},
		{T_NUMBER, "idx", 1004},
		{T_TABLE, "friend", "MSG_FRIEND"},
		{T_ARRAY, "friends", "MSG_FRIEND"},
		--[[
		create = function()
			return
			{
				id = "xxxxx",
				idx = 100,
				friend = MESSAGES.MSG_FRIEND.create(),
				friends = {},
			}
		end
		--]]
	},
}

--[[
MESSAGES.__index = function(t,k)
	return MESSAGES[k]
end
MESSAGES.__newindex = function(t, k, v)
	print("error! config file shouldn't be set")
end

local tab = {}
setmetatable(tab, MESSAGES)
return tab
--]]

return MESSAGES
