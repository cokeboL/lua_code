local T_NUMBER = 1
local T_STRING = 2
local T_TABLE  = 3
local T_ARRAY  = 4
local T_BOOL   = 5

local T_IDX = 1
local K_IDX = 2
local V_IDX = 3
local M_IDX = 3
local A_IDX = 3

local NAME_KEY = "_z"

local MESSAGES = {}
local MESSAGES_NAME_MAP = {}
local MESSAGES_ORDER_MAP = {}



local strSub = string.sub
local strLen = string.len
local strByte = string.byte
local strChar = string.char
local mathFloor = math.floor
local tonumber = tonumber
local tostring = tostring
local type = type
local pairs = pairs
local ipairs = ipairs
local setmetatable = setmetatable
local print = print

local LuaProto = {}
local msgsMap = {}

local str2num
local num2str
local str2lenstr
local lenstr2str
local arr2str
local str2arr
local create
local newMsg
local clearArr
local getMsg
local getMsgN
local encode
local decode


str2num = function(s)
	local len = strByte(s, 1)
	--local nums = strSub(s, 2, 1+len)
	local num = tonumber(strSub(s, 2, 1+len))
	s = strSub(s, 2+len)
	return num, s
end

num2str = function(num)
	local s = tostring(num)
	local len = strLen(s)
	s = strChar(len) .. s
	return s
end

lenstr2str = function(s)
	local higher = strByte(s, 1)
	local lower = strByte(s, 2)
	local len = (higher * 255) + lower
	local str = strSub(s, 3, 2+len)
	s = strSub(s, 3+len)
	return str, s
end

str2lenstr = function(str)
	local len = strLen(str)
	local higher = mathFloor(len / 255)
	local lower = mathFloor(len % 255)
	local s = strChar(higher) .. strChar(lower) .. str
	return s
end

arr2str = function(arr, msgName)
	local len = #arr

	local higher = mathFloor(len / 255)
	local lower = mathFloor(len % 255)
	local s = strChar(higher) .. strChar(lower)

	--local s = strChar(len) .. ""
	for i, v in ipairs(arr) do
		s = s .. encode(v, msgName)
	end

	return s
end

str2arr = function(str, msgName)
	--print("str2arr: ", str, msgName)
	local higher = strByte(str, 1)
	local lower = strByte(str, 2)
	local len = (higher * 255) + lower
	str = strSub(str, 3)
	--local len = strByte(str, 1)
	local arr = {}
	
	for i=1, len do
		arr[i], str = decode(str, msgName)
	end

	return arr, str
end

create = function(msgName)
	local msgdef = MESSAGES[msgName]
	local tab = {}
	tab[NAME_KEY] = msgName
	for _, v in ipairs(msgdef) do
		if v[T_IDX] == T_NUMBER then
			tab[ v[K_IDX] ] = v[V_IDX] or 0
		elseif v[T_IDX] == T_STRING then
			tab[ v[K_IDX] ] = v[V_IDX] or ""
		elseif v[T_IDX] == T_TABLE then
			--tab[v[K_IDX]] = create(v[M_IDX])
		elseif v[T_IDX] == T_ARRAY then
			tab[ v[K_IDX] ] = {}
		elseif v[T_IDX] == T_BOOL then
			tab[ v[K_IDX] ] = v[V_IDX]
		end
	end
	return tab
end

newMsg = function(msgName)
	local mt
	if MESSAGES[msgName].create then
		mt = MESSAGES[msgName].create()
		mt[NAME_KEY] = msgName
	else
		mt = create(msgName)

	end

	--[[
	mt.__index = function(t,k)
		return mt[k]
	end
	mt.__newindex = function(t, k, v)
		if (not mt[k]) then
			print(string.format("error set, empty key: %s, (value: %s)", k, v))
		elseif (type(mt[k]) ~= type(v)) then
			print(string.format("error set, key: %s, (value: %s), need type: %s, input type: %s", k, v, type(mt[k]), type(v)))
		else
			mt[k] = v
		end
	end

	local msg = {}
	setmetatable(msg, mt)
	return msg
	--]]
	return mt
end
LuaProto.newMsg = newMsg

encode = function(msg, mname)
	if not msg then
		return "0"
	end
	msgName = mname or msg[NAME_KEY]
	local id = MESSAGES_NAME_MAP[msgName]
	--[[
	for k, v in pairs(MESSAGES_NAME_MAP) do
		print(k, v)
	end
	print("encode: ", id, msgName)
	--]]
	local msgdef = MESSAGES[msgName]

	local s
	if mname then
		s = "1"
	else
		s = "1" .. strChar(mathFloor(id / 255)) .. strChar(mathFloor(id % 255))
	end
	for _, v in ipairs(msgdef) do
		if v[T_IDX] == T_NUMBER then
			s = s .. num2str(msg[ v[K_IDX] ])
		elseif v[T_IDX] == T_STRING then
			s = s .. str2lenstr(msg[ v[K_IDX] ])
		elseif v[T_IDX] == T_TABLE then
			s = s .. encode(msg[ v[K_IDX] ], v[M_IDX])
		elseif v[T_IDX] == T_ARRAY then
			s = s .. arr2str(msg[ v[K_IDX] ], v[M_IDX])
		elseif v[T_IDX] == T_BOOL then
			if msg[ v[K_IDX] ] == true then
				s = s .. 1
			else
				s = s .. 0
			end
		end
	end
	return s --string.char(s:len()) .. s
end
LuaProto.encode = encode

decode = function(str, mname)
	if strChar(strByte(str, 1)) == "0" then
		str = strSub(str, 2)
		return nil
	end

	str = strSub(str, 2)

	local msgName
	if mname then
		msgName = mname
	else
		local higher = strByte(str, 1)
		local lower = strByte(str, 2)
		local id = (higher * 255) + lower
		msgName = mname or MESSAGES_ORDER_MAP[id]
		str = strSub(str, 3)
	end

	local msgdef = MESSAGES[msgName]
	local msg = {}
	msg[NAME_KEY] = msgName

	for _, v in ipairs(msgdef) do
		if v[T_IDX] == T_NUMBER then
			msg[v[K_IDX]], str = str2num(str)
		elseif v[T_IDX] == T_STRING then
			msg[v[K_IDX]], str = lenstr2str(str)
		elseif v[T_IDX] == T_TABLE then
			msg[v[K_IDX]], str = decode(str, v[M_IDX])
		elseif v[T_IDX] == T_ARRAY then
			msg[v[K_IDX]], str = str2arr(str, v[A_IDX])
		elseif v[T_IDX] == T_BOOL then
			if strChar(strByte(str, 1)) == "1" then
				msg[v[K_IDX]] = true
			else
				msg[v[K_IDX]] = false
			end
			str = strSub(str, 2)
		end
	end
	return msg, str --string.char(s:len()) .. s
end
LuaProto.decode = decode

--[[
function LuaProto.foreach(tab, cb)
	for k, v in pairs(getmetatable(tab)) do
		if k ~= "__index" and k ~= "__newindex" then
			cb(k, v)
		end
	end
end
--]]

---[[
function LuaProto.dump(msg)
	--local str = encode(msg, msgName)
	--local tab = decode(str, msgName)
	local msgName = msg[NAME_KEY]
	if not msgName then
		print("LuaProto.dump error: not a LuaProto Msg!")
		return
	end
	print(msgName .. ":")
	local prex = "  "
	local xx = " = "
	function dump_(tab, pre, floor)
		for k, v in pairs(tab) do
			if type(v) == 'table' then
				if floor == 1 then
					print(k .. xx .. "\n{")
				else
					print(pre .. k .. xx .. "\n" .. pre .. "{")
				end
				dump_(v, pre .. pre, floor + 1)
				if floor == 1 then
					print("}")
				else
					print(pre .. "}")
				end
			else
				if k ~= NAME_KEY then
					if floor == 1 then
						print(k .. xx .. tostring(v))
					else
						print(pre .. k .. xx .. tostring(v))
					end
				end
			end
		end
	end
	dump_(msg, prex, 1)
end
--]]

function LuaProto.load(...)
	local files = {...}
	local cfg, mt
	for _, file in ipairs(files) do
		cfg = require(file)
		for k, v in pairs(cfg) do
			MESSAGES[k] = v
		end
	end
	
	for k, _ in pairs(MESSAGES) do
		MESSAGES_ORDER_MAP[#MESSAGES_ORDER_MAP + 1] = k
	end
	table.sort(MESSAGES_ORDER_MAP, function(a, b)
		return (a < b)
	end)
	for i, k in pairs(MESSAGES_ORDER_MAP) do
		MESSAGES_NAME_MAP[k] = i
	end
end

return LuaProto
