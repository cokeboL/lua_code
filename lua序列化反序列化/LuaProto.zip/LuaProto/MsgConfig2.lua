local T_NUMBER = 1
local T_STRING = 2
local T_TABLE  = 3
local T_ARRAY  = 4
local T_BOOL   = 5

local MESSAGES
MESSAGES =
{
	MSG_FRIEND2 =
	{
		{T_STRING, "name", "name"},
		{T_NUMBER, "coin", 120},
		{T_STRING, "health", "ok"},
		--[[
		create = function()
			return
			{
				name = "name",
				coin = 120,
				health = "ok",
			}
		end
		--]]
	},

	MSG_PLAYER2 =
	{
		{T_STRING, "id", "xxxx2"},
		{T_NUMBER, "idx", 1004},
		{T_TABLE, "friend", "MSG_FRIEND"},
		{T_ARRAY, "friends", "MSG_FRIEND"},
		{T_BOOL,  "xx", false}
		--[[
		create = function()
			return
			{
				id = "xxxxx",
				idx = 100,
				friend = MESSAGES.MSG_FRIEND.create(),
				friends = {},
			}
		end
		--]]
	},
}


--[[
MESSAGES.__index = function(t,k)
	return MESSAGES[k]
end
MESSAGES.__newindex = function(t, k, v)
	print("error! config file shouldn't be set")
end

local tab = {}
setmetatable(tab, MESSAGES)
return tab
--]]

return MESSAGES
