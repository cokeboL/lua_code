local testJ2L={}

testJ2L.id_1={id="id_1",num=111,str="str1"}
testJ2L.id_1.keyT={ a=3, b="strb"}

testJ2L.id_2={id="id_2",num=222,str="str2"}
testJ2L.id_2.keyT={ a=4, b="strc"}

testJ2L.id_3={id="id_3",num=333,str="str3"}
testJ2L.id_3.keyT={ a=5, b="strc"}

return testJ2L