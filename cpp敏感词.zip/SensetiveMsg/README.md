# SensetiveMsg
c++过滤敏感词

void SensetiveMsg::init()
这里请根据自己的配置文件格式初始化
每次调用word2Tree是加入一个敏感词

用法参考
void testSensetiveMsg()
