#ifndef _SensetiveMsg_H_
#define _SensetiveMsg_H_

#include <map>
#include <vector>
#include <string>

typedef class SensetiveNode{
public:
	SensetiveNode() : _key(0), _tail(false)
	{
	}
	~SensetiveNode()
	{
		for (std::map<char, struct SensetiveNode*>::iterator it = _child.begin(); it != _child.end(); it++)
		{
			delete it->second;
		}
		_child.clear();
	}

	char _key;
	bool _tail;
	std::map<char, struct SensetiveNode*> _child;
}SensetiveNode;


class SensetiveMsg{
public:
	static SensetiveMsg *getInstance();

	std::string getSafeString(std::string &str, const char mask = '*');

private:
	SensetiveMsg();

	~SensetiveMsg();

	void init();

	SensetiveNode *byte2tree(SensetiveNode *parent, char key, bool tail);

	void word2Tree(std::string &word);

	int parse(std::string &word, int idx);

	std::map<char, SensetiveNode*> _tree;
	
	static SensetiveMsg _instance;
};

extern void testSensetiveMsg();

#endif // _SensetiveMsg_H_
