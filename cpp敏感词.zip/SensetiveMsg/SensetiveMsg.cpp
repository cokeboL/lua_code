#include <iostream>

#include "SensetiveMsg.h"


SensetiveMsg SensetiveMsg::_instance;

SensetiveMsg::SensetiveMsg()
{
	this->init();
}

SensetiveMsg::~SensetiveMsg()
{
	for (std::map<char, SensetiveNode*>::iterator it = _tree.begin(); it != _tree.end(); it++)
	{
		delete it->second;
	}
	_tree.clear();
}

SensetiveMsg *SensetiveMsg::getInstance()
{
	return &SensetiveMsg::_instance;
}

//这里请根据自己的配置文件格式初始化
//每次调用word2Tree是加入一个敏感词
void SensetiveMsg::init()
{
	std::string s("abc");
	word2Tree(s);

	std::string s2("abcd");
	word2Tree(s2);

	std::string s3("abdd");
	word2Tree(s3);

	std::string s4("ymdts");
	word2Tree(s4);
}

SensetiveNode *SensetiveMsg::byte2tree(SensetiveNode *parent, char key, bool tail)
{
	SensetiveNode *node = parent->_child[key];
	if (node)
	{
		node->_tail = tail || node->_tail;
	}
	else
	{
		node = new SensetiveNode;
		node->_key = key;
		node->_tail = tail;
		parent->_child[key] = node;
	}

	return node;
}

void SensetiveMsg::word2Tree(std::string &word)
{
	if (word.size() == 0)
	{
		return;
	}

	SensetiveNode *parent = _tree[word[0]];
	if (!parent)
	{
		parent = new SensetiveNode;
		_tree[word[0]] = parent;
	}
	parent->_key = word[0];
	if (word.size() == 1)
	{
		parent->_tail = true;
	}

	SensetiveNode *tmpparent = parent;
	for (int i = 1; i < word.size(); i++)
	{
		tmpparent = byte2tree(tmpparent, word[i], (i == word.size() - 1));
	}
}

int SensetiveMsg::parse(std::string &word, int idx)
{
	SensetiveNode *parent = _tree[word[0]];

	if (parent)
	{
		std::vector<int> tails;
		SensetiveNode *tmpparent = parent;
		if (tmpparent && tmpparent->_tail)
		{
			tails.push_back(0);
		}

		for (int i = 1; i < word.size(); i++)
		{
			tmpparent = tmpparent->_child[word[i]];
			if (tmpparent)
			{
				if (tmpparent->_tail)
				{
					tails.push_back(i);
				}
			}
			else
			{
				break;
			}
		}
		if (tails.size() > 0)
		{
			return idx + tails[tails.size() - 1];
		}
	}
	else
	{
		_tree.erase(word[0]);
	}

	return -1;
}

std::string SensetiveMsg::getSafeString(std::string &str, const char mask)
{
	std::string newstr(str);
	int i = 0, idx;
	for (i = 0; i < str.size();)
	{
		std::string subs = str.substr(i);
		idx = parse(subs, i);
		if (idx > 0)
		{
			for (int j = i; j <= idx; j++)
			{
				newstr[j] = mask;
			}
			i = idx + 1;
		}
		else
		{
			i += 1;
		}
	}

	return newstr;
}


void testSensetiveMsg()
{
	std::string s = SensetiveMsg::getInstance()->getSafeString(std::string("abc"));
	std::cout << "---- safe str: " << s << std::endl;

	std::string s2 = SensetiveMsg::getInstance()->getSafeString(std::string("xxxcaabddfabcddsfymdtsaaa"), '=');
	std::cout << "---- safe str2: " << s2 << std::endl;
}